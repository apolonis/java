package com.example.demo.Controller;


import com.example.demo.Model.User;
import com.example.demo.Repository.UserRepository;
import com.example.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;

import java.util.Comparator;
import java.util.List;

@Controller
public class  UsermanagementController {

    @Autowired
    UserRepository repository;

    @Autowired
    private UserService userService;

    @GetMapping("/userManagement")
    public String getUserManagement(Model model){
        List<User> users = userService.findAll();
        users.sort(Comparator.comparing(o -> o.getId()));
        model.addAttribute("users", users);

        model.addAttribute ("title", "Informations of all users");

        return "userManagement";
    }
    @GetMapping("/")
    public String getLogIn(Model model) {

        model.addAttribute("title", "Welcome to user management");

        return "userLogin";
    }
}
