package com.javainuse.controller;

import com.javainuse.dao.ProductRepository;
import com.javainuse.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/product/")
public class ProductController {

        @Autowired
        private ProductRepository productRepository;

        // Return all products //
        @GetMapping
        public List<Product> index(){
            return (List<Product>) productRepository.findAll();
        }

        // Add Products //
        @PostMapping
        public Product create(@RequestBody Product product){
            productRepository.save(product);
            return product;
        }
    }


