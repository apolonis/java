package com.javainuse.dto;

import lombok.Data;

@Data
public class ProductPostDTO {
    private String name;
    private int categoryId;
}
