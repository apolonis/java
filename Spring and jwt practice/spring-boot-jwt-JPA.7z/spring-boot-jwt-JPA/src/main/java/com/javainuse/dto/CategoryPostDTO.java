package com.javainuse.dto;

import lombok.Data;

@Data
public class CategoryPostDTO {
    private String name;
}
